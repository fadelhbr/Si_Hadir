package com.teamone.sihadir.model;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hadir.R;

public class ProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
