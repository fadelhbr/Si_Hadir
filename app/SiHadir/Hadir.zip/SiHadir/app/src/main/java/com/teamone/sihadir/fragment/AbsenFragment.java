package com.teamone.sihadir.fragment;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import com.example.hadir.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AbsenFragment extends Fragment {

    private Button btnAbsen;
    private TextView tvStatus, tvLokasi;
    private ImageView ivFoto;
    private FusedLocationProviderClient fusedLocationClient;
    private Uri photoUri;

    private final double OFFICE_LATITUDE = -6.123456;
    private final double OFFICE_LONGITUDE = 106.123456;
    private final float ALLOWED_DISTANCE = 100; // dalam meter

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 2;
    private static final int CAMERA_REQUEST_CODE = 3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_absen, container, false);

        btnAbsen = view.findViewById(R.id.btn_absen);
        tvStatus = view.findViewById(R.id.tv_status);
        tvLokasi = view.findViewById(R.id.tv_lokasi);
        ivFoto = view.findViewById(R.id.iv_foto);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnAbsen.setOnClickListener(v -> prosesAbsen());
    }

    private void prosesAbsen() {
        // Check location permission first
        if (ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermission();
            return;
        }

        getCurrentLocation();
    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(requireActivity(), new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            checkLocationAndProceed(location);
                        } else {
                            tvStatus.setText("Tidak dapat mendapatkan lokasi. Mohon aktifkan GPS.");
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvStatus.setText("Gagal mendapatkan lokasi: " + e.getMessage());
                    }
                });
    }

    private void checkLocationAndProceed(Location location) {
        float[] results = new float[1];
        Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                OFFICE_LATITUDE, OFFICE_LONGITUDE, results);

        String locationInfo = String.format(Locale.getDefault(),
                "Lokasi Anda: %.6f, %.6f\nJarak dari kantor: %.0f meter",
                location.getLatitude(), location.getLongitude(), results[0]);
        tvLokasi.setText(locationInfo);

        if (results[0] <= ALLOWED_DISTANCE) {
            requestCameraPermission();
        } else {
            tvStatus.setText("Anda berada di luar radius kantor!");
            Toast.makeText(requireContext(),
                    "Anda harus berada dalam radius " + ALLOWED_DISTANCE + " meter dari kantor",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void requestLocationPermission() {
        requestPermissions(
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                LOCATION_PERMISSION_REQUEST_CODE
        );
    }

    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST_CODE
            );
        } else {
            openCamera();
        }
    }

    private Uri createImageUri() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        return FileProvider.getUriForFile(requireContext(),
                requireContext().getPackageName() + ".fileprovider",
                image);
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            photoUri = createImageUri();
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(),
                    "Gagal membuat file untuk foto",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                prosesAbsen();
            } else {
                tvStatus.setText("Izin lokasi diperlukan untuk absensi");
            }
        } else if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                tvStatus.setText("Izin kamera diperlukan untuk absensi");
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == requireActivity().RESULT_OK) {
            if (photoUri != null) {
                ivFoto.setVisibility(View.VISIBLE);
                ivFoto.setImageURI(photoUri);
                submitAttendance(photoUri);
            }
        }
    }

    private void submitAttendance(Uri photoUri) {
        // TODO: Implementasi pengiriman data absensi ke server
        // 1. Upload foto
        // 2. Kirim data absensi (waktu, lokasi, foto)
        // 3. Update database lokal jika diperlukan

        tvStatus.setText("Absen berhasil dicatat!");
        Toast.makeText(requireContext(), "Absen berhasil!", Toast.LENGTH_SHORT).show();
    }
}